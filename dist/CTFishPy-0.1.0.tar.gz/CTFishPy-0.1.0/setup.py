# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['ctfishpy', 'ctfishpy.GUI', 'ctfishpy.Unet']

package_data = \
{'': ['*']}

install_requires = \
['matplotlib>=3.2.0,<4.0.0',
 'natsort>=7.0.1,<8.0.0',
 'numpy>=1.18.1,<2.0.0',
 'opencv-contrib-python>=4.2.0,<5.0.0',
 'pandas>=1.0.1,<2.0.0',
 'pyqt5>=5.14.1,<6.0.0',
 'qtpy>=1.9.0,<2.0.0',
 'tqdm>=4.43.0,<5.0.0']

setup_kwargs = {
    'name': 'ctfishpy',
    'version': '0.1.0',
    'description': 'Python project for analysis of zebrafish CT data using deep learning.',
    'long_description': None,
    'author': 'Abdelwahab Kawafi',
    'author_email': 'a.kawafi@bristol.ac.uk',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '==3.6.9',
}


setup(**setup_kwargs)
